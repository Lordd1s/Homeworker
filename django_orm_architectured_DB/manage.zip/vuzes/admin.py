from django.contrib import admin

from vuzes import models

# Register your models here.
admin.site.register(models.Student)
admin.site.register(models.VuzName)
admin.site.register(models.Speciality)
